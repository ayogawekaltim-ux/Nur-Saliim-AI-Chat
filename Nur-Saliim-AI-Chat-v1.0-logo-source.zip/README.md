# Nur & Saliim AI Chat

Aplikasi Android AI Chat dengan OpenRouter sebagai gateway model.

## Fitur fondasi v1.0
- Home / daftar chat
- Chat Room
- Model Selector: FREE, HEMAT, SEDANG, PRO
- Harga input/output token
- Explore model
- History lokal
- Memory lokal
- Settings
- OpenRouter API Key
- Voice input Android
- Attachment picker
- Model catalog dari OpenRouter `/models`
- Default model murah/HEMAT
- Tidak ada mode AUTO

## Build
Buka folder ini di Android Studio terbaru yang mendukung AGP 8.7.x, lalu:
1. Sync Gradle.
2. Run di emulator/HP Android.
3. Masukkan OpenRouter API Key di Settings.
4. Pilih model.
5. Mulai chat.

## Catatan
Harga contoh pada daftar awal hanya fallback UI. Jika API key tersedia, aplikasi mengambil katalog model langsung dari OpenRouter dan menghitung tier berdasarkan harga.

Untuk produksi, API key sebaiknya dipisahkan per pengguna dan tidak ditanam di APK. Jika aplikasi akan dijual ke banyak pengguna, pertimbangkan backend milik sendiri untuk billing, abuse protection, dan penyimpanan memory.

## App icon
Logo aplikasi menggunakan foto yang diberikan pengguna, dipotong square agar cocok sebagai launcher icon.

## Build APK otomatis via GitHub
Project ini juga menyediakan `.github/workflows/build-apk.yml`.
Setelah project di-upload ke repository GitHub, jalankan workflow **Build Nur & Saliim AI Chat APK** dari tab Actions. Hasil `app-debug.apk` akan tersedia sebagai artifact untuk diunduh dan dipasang di Android.
