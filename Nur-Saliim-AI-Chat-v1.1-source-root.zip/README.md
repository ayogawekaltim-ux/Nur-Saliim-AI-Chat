# Nur & Saliim AI Chat — v1.1

Android native AI chat app using OpenRouter.

## Isi versi 1.1

- Kotlin + Jetpack Compose
- Android API 35 / min API 26
- OpenRouter Chat Completions
- Model selector: FREE / HEMAT / SEDANG / PRO
- Harga input/output model ditampilkan
- History chat lokal
- Memory lokal
- Settings API key dan default model
- Voice input
- Attachment picker
- Logo aplikasi menggunakan foto yang diberikan pengguna
- GitHub Actions untuk membuat APK Debug
- **Tidak membutuhkan `gradlew`** di repository; workflow memasang Gradle 8.9 langsung

## Cara membuat APK di GitHub dari HP

1. Buat repository GitHub kosong.
2. Upload **seluruh isi ZIP** ini ke repository. Pastikan `build.gradle.kts`, `settings.gradle.kts`, folder `app/`, dan folder `.github/` berada di root repository.
3. Commit ke branch `main`.
4. Buka tab **Actions**.
5. Pilih **Build Nur & Saliim AI Chat APK**.
6. Jalankan **Run workflow** jika workflow belum otomatis berjalan.
7. Setelah berhasil, buka hasil workflow.
8. Pada bagian **Artifacts**, download `Nur-Saliim-AI-Chat-debug`.
9. Ekstrak ZIP artifact tersebut, lalu install `app-debug.apk` di Android.

## Jika Actions gagal

Buka run yang gagal → buka job `build` → buka langkah yang berwarna merah → lihat pesan error. Jangan mengubah workflow secara acak. Error harus diperbaiki berdasarkan langkah yang gagal.

## Catatan

Build ini menghasilkan APK Debug. APK dapat dipasang untuk pengujian. Untuk rilis publik/Play Store, gunakan signing release dan konfigurasi keamanan produksi.

API key OpenRouter disimpan di penyimpanan lokal aplikasi pada versi ini. Jangan membagikan API key kepada orang lain.
