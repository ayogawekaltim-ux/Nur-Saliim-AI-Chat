package com.nurandsaliim.aichat

data class AiModel(
    val id: String,
    val name: String,
    val provider: String,
    val tier: String,
    val inputPrice: String,
    val outputPrice: String,
    val context: String = "128K",
    val supportsVision: Boolean = false
)

data class ChatMessage(
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatSession(
    val id: String,
    val title: String,
    val modelId: String,
    val messages: List<ChatMessage>,
    val updatedAt: Long = System.currentTimeMillis()
)

data class MemoryItem(
    val id: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)
