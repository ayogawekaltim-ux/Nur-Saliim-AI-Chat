package com.nurandsaliim.aichat

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("nur_saliim_store")

class AppStore(private val context: Context) {
    private val gson = Gson()
    private val apiKeyKey = stringPreferencesKey("openrouter_api_key")
    private val modelKey = stringPreferencesKey("default_model")
    private val chatsKey = stringPreferencesKey("chats_json")
    private val memoriesKey = stringPreferencesKey("memories_json")

    val apiKey: Flow<String> = context.store.data.map { it[apiKeyKey] ?: "" }
    val defaultModel: Flow<String> = context.store.data.map {
        it[modelKey] ?: "deepseek/deepseek-chat"
    }
    val chats: Flow<List<ChatSession>> = context.store.data.map {
        val raw = it[chatsKey] ?: "[]"
        gson.fromJson(raw, object : TypeToken<List<ChatSession>>() {}.type) ?: emptyList()
    }
    val memories: Flow<List<MemoryItem>> = context.store.data.map {
        val raw = it[memoriesKey] ?: "[]"
        gson.fromJson(raw, object : TypeToken<List<MemoryItem>>() {}.type) ?: emptyList()
    }

    suspend fun saveApiKey(value: String) = context.store.edit { it[apiKeyKey] = value }
    suspend fun saveDefaultModel(value: String) = context.store.edit { it[modelKey] = value }

    suspend fun saveChats(value: List<ChatSession>) =
        context.store.edit { it[chatsKey] = gson.toJson(value) }

    suspend fun saveMemories(value: List<MemoryItem>) =
        context.store.edit { it[memoriesKey] = gson.toJson(value) }
}
