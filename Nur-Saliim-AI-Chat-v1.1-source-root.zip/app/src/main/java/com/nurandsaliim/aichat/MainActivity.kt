package com.nurandsaliim.aichat

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.navigation.compose.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Green = Color(0xFF10B981)
private val GreenDark = Color(0xFF059669)
private val Ink = Color(0xFF101828)
private val Soft = Color(0xFFF5F8F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        setContent { NurSaliimApp() }
    }
}

@Composable
fun NurSaliimApp() {
    val context = LocalContext.current
    val store = remember { AppStore(context) }
    val scope = rememberCoroutineScope()
    val chats by store.chats.collectAsState(initial = emptyList())
    val memories by store.memories.collectAsState(initial = emptyList())
    val apiKey by store.apiKey.collectAsState(initial = "")
    val defaultModel by store.defaultModel.collectAsState(initial = "deepseek/deepseek-chat")
    var models by remember { mutableStateOf(sampleModels()) }

    LaunchedEffect(apiKey) {
        if (apiKey.isNotBlank()) {
            runCatching {
                val remote = OpenRouter.service.models().data.map { m ->
                    val prompt = m.pricing?.prompt ?: "0"
                    val completion = m.pricing?.completion ?: "0"
                    AiModel(
                        id = m.id,
                        name = m.name ?: m.id,
                        provider = m.id.substringBefore("/"),
                        tier = tierFor(prompt, completion),
                        inputPrice = formatPrice(prompt),
                        outputPrice = formatPrice(completion),
                        context = ((m.context_length ?: 0) / 1000).let { if (it > 0) "${it}K" else "—" },
                        supportsVision = m.architecture?.input_modalities?.contains("image") == true
                    )
                }
                if (remote.isNotEmpty()) models = remote
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Color(0xFF0EA5A4),
            background = Color.White,
            surface = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        val nav = rememberNavController()
        NavHost(navController = nav, startDestination = "home") {
            composable("home") {
                HomeScreen(
                    chats = chats,
                    defaultModel = defaultModel,
                    onNewChat = {
                        val id = UUID.randomUUID().toString()
                        scope.launch {
                            store.saveChats(
                                listOf(
                                    ChatSession(id, "Percakapan Baru", defaultModel, emptyList())
                                ) + chats
                            )
                            nav.navigate("chat/$id")
                        }
                    },
                    onOpenChat = { nav.navigate("chat/$it") },
                    onHistory = { nav.navigate("history") },
                    onExplore = { nav.navigate("explore") },
                    onSettings = { nav.navigate("settings") }
                )
            }
            composable("chat/{id}") { back ->
                val id = back.arguments?.getString("id") ?: return@composable
                ChatScreen(
                    session = chats.firstOrNull { it.id == id }
                        ?: ChatSession(id, "Percakapan Baru", defaultModel, emptyList()),
                    apiKey = apiKey,
                    models = models,
                    memories = memories,
                    onBack = { nav.popBackStack() },
                    onSave = { updated ->
                        scope.launch {
                            val all = chats.map { if (it.id == updated.id) updated else it }
                            store.saveChats(all)
                        }
                    },
                    onModel = { nav.navigate("models") },
                    onAddMemory = { text ->
                        scope.launch {
                            store.saveMemories(memories + MemoryItem(UUID.randomUUID().toString(), text))
                        }
                    }
                )
            }
            composable("history") {
                HistoryScreen(chats, { nav.navigate("chat/$it") }, { nav.popBackStack() })
            }
            composable("explore") {
                ExploreScreen(models, { nav.navigate("models") }, { nav.popBackStack() })
            }
            composable("models") {
                ModelSelectorScreen(
                    models = models,
                    selected = defaultModel,
                    onSelect = { m ->
                        scope.launch { store.saveDefaultModel(m.id) }
                        nav.popBackStack()
                    },
                    onBack = { nav.popBackStack() }
                )
            }
            composable("settings") {
                SettingsScreen(
                    apiKey = apiKey,
                    defaultModel = defaultModel,
                    memories = memories,
                    models = models,
                    onBack = { nav.popBackStack() },
                    onApiKey = { scope.launch { store.saveApiKey(it) } },
                    onModel = { nav.navigate("models") },
                    onDeleteMemory = { id ->
                        scope.launch { store.saveMemories(memories.filterNot { it.id == id }) }
                    }
                )
            }
        }
    }
}

@Composable
fun AppHeader(title: String, onBack: (() -> Unit)? = null, action: @Composable (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        } else {
            androidx.compose.foundation.Image(
                painter = painterResource(R.drawable.app_logo),
                contentDescription = "Logo Nur & Saliim",
                modifier = Modifier.size(44.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
            if (title == "Nur & Saliim") Text("AI Chat", color = GreenDark, fontSize = 12.sp)
        }
        action?.invoke()
    }
}

@Composable
fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        listOf(
            "home" to (Icons.Default.ChatBubble to "Chat"),
            "history" to (Icons.Default.History to "History"),
            "explore" to (Icons.Default.AutoAwesome to "Explore"),
            "settings" to (Icons.Default.Settings to "Settings")
        ).forEach { (route, pair) ->
            NavigationBarItem(
                selected = selected == route,
                onClick = { onSelect(route) },
                icon = { Icon(pair.first, null) },
                label = { Text(pair.second) }
            )
        }
    }
}

@Composable
fun HomeScreen(
    chats: List<ChatSession>, defaultModel: String,
    onNewChat: () -> Unit, onOpenChat: (String) -> Unit,
    onHistory: () -> Unit, onExplore: () -> Unit, onSettings: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    Scaffold(
        bottomBar = { BottomBar("home") { route ->
            when(route) { "history" -> onHistory(); "explore" -> onExplore(); "settings" -> onSettings() }
        }}
    ) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(horizontal = 18.dp)) {
            AppHeader(
                "Nur & Saliim",
                action = {
                    IconButton(onClick = {}) { Icon(Icons.Default.Search, "Cari") }
                    IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, "Menu") }
                }
            )
            Text("AI Chat", color = GreenDark, fontSize = 12.sp, modifier = Modifier.padding(start = 18.dp))
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari percakapan...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(18.dp), singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onNewChat,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp))
                Text("Chat Baru", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            Text("Percakapan Terbaru", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            val filtered = chats.filter { it.title.contains(search, true) }.take(20)
            if (filtered.isEmpty()) {
                EmptyState("Belum ada percakapan", "Mulai chat baru dengan Nur & Saliim.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.id }) { chat ->
                        ChatListItem(chat) { onOpenChat(chat.id) }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatListItem(chat: ChatSession, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Soft).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8FFF5)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ChatBubbleOutline, null, tint = GreenDark)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(formatTime(chat.updatedAt), color = Color.Gray, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
}

@Composable
fun ChatScreen(
    session: ChatSession, apiKey: String, models: List<AiModel>, memories: List<MemoryItem>,
    onBack: () -> Unit, onSave: (ChatSession) -> Unit, onModel: () -> Unit,
    onAddMemory: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var messages by remember(session.id) { mutableStateOf(session.messages) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    val context = LocalContext.current
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) input = text
    }
    val attachLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) input = "$input\n[Lampiran: ${uri.lastPathSegment ?: "file"}]".trim()
    }
    val model = models.firstOrNull { it.id == session.modelId } ?: models.first()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) list.animateScrollToItem(messages.lastIndex)
    }

    Scaffold(
        topBar = {
            AppHeader(session.title, onBack = onBack, action = {
                AssistChip(
                    onClick = onModel,
                    label = { Text("${model.name.take(22)} • ${model.tier}") },
                    leadingIcon = { Icon(Icons.Default.Bolt, null) }
                )
            })
        }
    ) { p ->
        Column(Modifier.fillMaxSize().padding(p)) {
            if (memories.isNotEmpty()) {
                Text(
                    "Memori aktif • ${memories.size} tersimpan",
                    color = GreenDark, fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
                )
            }
            if (error != null) {
                Text(error!!, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp))
            }
            LazyColumn(
                state = list,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages) { msg -> MessageBubble(msg) }
                if (sending) {
                    item { AiBubble("Nur & Saliim sedang berpikir…") }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                IconButton(onClick = { attachLauncher.launch("*/*") }) {
                    Icon(Icons.Default.AttachFile, "Lampiran")
                }
                IconButton(onClick = {
                    voiceLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                    })
                }) { Icon(Icons.Default.Mic, "Suara") }
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ketik pesan Anda...") },
                    shape = RoundedCornerShape(20.dp),
                    maxLines = 5
                )
                Spacer(Modifier.width(6.dp))
                FilledIconButton(
                    enabled = input.isNotBlank() && !sending,
                    onClick = {
                        val prompt = input.trim()
                        input = ""
                        val newUser = ChatMessage("user", prompt)
                        messages = messages + newUser
                        sending = true
                        error = null
                        scope.launch {
                            try {
                                if (apiKey.isBlank()) throw IllegalStateException("Masukkan OpenRouter API Key di Settings terlebih dahulu.")
                                val contextMemory = memories.joinToString("\n") { "- ${it.text}" }
                                val msgs = buildList {
                                    if (contextMemory.isNotBlank()) add(ApiMessage("system", "Memori pengguna yang relevan:\n$contextMemory"))
                                    messages.takeLast(30).forEach { add(ApiMessage(it.role, it.content)) }
                                }
                                val response = OpenRouter.service.chat(
                                    "Bearer $apiKey",
                                    request = ChatRequest(model = model.id, messages = msgs)
                                )
                                val answer = response.choices.firstOrNull()?.message?.content?.toString()
                                    ?: response.error?.message
                                    ?: "AI tidak mengembalikan jawaban."
                                messages = messages + ChatMessage("assistant", answer)
                                val title = if (session.title == "Percakapan Baru") prompt.take(42) else session.title
                                onSave(session.copy(title = title, messages = messages, updatedAt = System.currentTimeMillis()))
                            } catch (e: Exception) {
                                error = e.message ?: "Terjadi kesalahan."
                            } finally { sending = false }
                        }
                    },
                    modifier = Modifier.size(52.dp),
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)
                ) { Icon(Icons.Default.Send, "Kirim") }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    if (message.role == "assistant") AiBubble(message.content)
    else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Surface(
            color = Green, shape = RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.content, color = Color.White, modifier = Modifier.padding(14.dp))
        }
    }
}

@Composable
fun AiBubble(text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFE7FFF4)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, null, tint = GreenDark)
        }
        Spacer(Modifier.width(8.dp))
        Surface(color = Soft, shape = RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp),
            modifier = Modifier.widthIn(max = 330.dp)) {
            Text(text, modifier = Modifier.padding(14.dp))
        }
    }
}

@Composable
fun HistoryScreen(chats: List<ChatSession>, open: (String) -> Unit, back: () -> Unit) {
    Scaffold(topBar = { AppHeader("History", back) }) { p ->
        if (chats.isEmpty()) EmptyState("History masih kosong", "Percakapan Anda akan muncul di sini.", Modifier.padding(p))
        else LazyColumn(Modifier.fillMaxSize().padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats.sortedByDescending { it.updatedAt }) { ChatListItem(it) { open(it.id) } }
        }
    }
}

@Composable
fun ModelSelectorScreen(models: List<AiModel>, selected: String, onSelect: (AiModel) -> Unit, onBack: () -> Unit) {
    var tier by remember { mutableStateOf("SEMUA") }
    Scaffold(topBar = { AppHeader("Pilih Model AI", onBack) }) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(horizontal = 16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("SEMUA","FREE","HEMAT","SEDANG","PRO").forEach {
                    FilterChip(selected = tier == it, onClick = { tier = it }, label = { Text(it) })
                }
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(models.filter { tier == "SEMUA" || it.tier == tier }) { model ->
                    ModelCard(model, selected == model.id) { onSelect(model) }
                }
            }
        }
    }
}

@Composable
fun ModelCard(model: AiModel, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        border = if (selected) androidx.compose.foundation.BorderStroke(1.5.dp, Green) else null,
        color = Color.White,
        shadowElevation = 1.dp
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAFBF5)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Psychology, null, tint = GreenDark)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(model.name, fontWeight = FontWeight.Bold, maxLines = 1)
                    Spacer(Modifier.width(6.dp))
                    Text(model.tier, color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text(model.provider, color = Color.Gray, fontSize = 12.sp)
                Text("Input ${model.inputPrice}  •  Output ${model.outputPrice}", fontSize = 11.sp)
                Text("Context ${model.context}", color = Color.Gray, fontSize = 11.sp)
            }
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = Green)
        }
    }
}

@Composable
fun ExploreScreen(models: List<AiModel>, openModels: () -> Unit, back: () -> Unit) {
    Scaffold(topBar = { AppHeader("Explore Model", back) }) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(horizontal = 16.dp)) {
            Text("Model OpenRouter", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Pilih model berdasarkan kebutuhan dan biaya token.", color = Color.Gray)
            Spacer(Modifier.height(16.dp))
            models.take(6).forEach { ModelCard(it, false, openModels) }
            Spacer(Modifier.height(12.dp))
            Button(onClick = openModels, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text("Lihat Semua Model")
            }
        }
    }
}

@Composable
fun SettingsScreen(
    apiKey: String, defaultModel: String, memories: List<MemoryItem>, models: List<AiModel>,
    onBack: () -> Unit, onApiKey: (String) -> Unit, onModel: () -> Unit,
    onDeleteMemory: (String) -> Unit
) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    Scaffold(topBar = { AppHeader("Settings", onBack) }) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Akun & API", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = key, onValueChange = { key = it },
                    label = { Text("OpenRouter API Key") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { IconButton(onClick = { onApiKey(key) }) { Icon(Icons.Default.Save, "Simpan") } }
                )
            }
            item {
                SettingRow("Model Default", models.firstOrNull { it.id == defaultModel }?.name ?: defaultModel, onModel)
            }
            item { Text("Aplikasi", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            item { SettingRow("Tema", "Terang") {} }
            item { SettingRow("Bahasa", "Bahasa Indonesia") {} }
            item { SettingRow("Simpan Riwayat Chat", "Aktif") {} }
            item { Text("Memory (${memories.size})", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            if (memories.isEmpty()) item { Text("Belum ada memory tersimpan.", color = Color.Gray) }
            items(memories, key = { it.id }) { memory ->
                Row(Modifier.fillMaxWidth().background(Soft, RoundedCornerShape(14.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Memory, null, tint = GreenDark)
                    Spacer(Modifier.width(10.dp))
                    Text(memory.text, Modifier.weight(1f))
                    IconButton(onClick = { onDeleteMemory(memory.id) }) { Icon(Icons.Default.DeleteOutline, "Hapus") }
                }
            }
            item { Text("Nur & Saliim AI Chat • v1.0.0", color = Color.Gray, modifier = Modifier.padding(vertical = 20.dp)) }
        }
    }
}

@Composable
fun SettingRow(title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Soft).clickable(onClick = onClick).padding(15.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, color = Color.Gray, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
}

@Composable
fun EmptyState(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.AutoAwesome, null, tint = Green, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.Gray)
    }
}

fun sampleModels() = listOf(
    AiModel("deepseek/deepseek-chat", "DeepSeek Chat", "DeepSeek", "HEMAT", "$0.00014/1K", "$0.00028/1K", "128K"),
    AiModel("google/gemini-2.0-flash-001", "Gemini 2.0 Flash", "Google", "HEMAT", "$0.00010/1K", "$0.00040/1K", "1M", true),
    AiModel("meta-llama/llama-3.3-70b-instruct", "Llama 3.3 70B", "Meta", "SEDANG", "$0.00059/1K", "$0.00080/1K", "128K"),
    AiModel("openai/gpt-4o-mini", "GPT-4o Mini", "OpenAI", "SEDANG", "$0.00015/1K", "$0.00060/1K", "128K", true),
    AiModel("openai/gpt-4o", "GPT-4o", "OpenAI", "PRO", "$0.00250/1K", "$0.01000/1K", "128K", true),
    AiModel("deepseek/deepseek-r1", "DeepSeek R1", "DeepSeek", "PRO", "$0.00055/1K", "$0.00219/1K", "64K")
)

fun tierFor(prompt: String, completion: String): String {
    val p = prompt.toDoubleOrNull() ?: 0.0
    val c = completion.toDoubleOrNull() ?: 0.0
    return when {
        p == 0.0 && c == 0.0 -> "FREE"
        p < 0.0005 && c < 0.001 -> "HEMAT"
        p < 0.003 && c < 0.01 -> "SEDANG"
        else -> "PRO"
    }
}

fun formatPrice(value: String): String {
    val d = value.toDoubleOrNull() ?: 0.0
    return "$" + "%.6f".format(Locale.US, d) + "/1K"
}

fun formatTime(time: Long): String =
    SimpleDateFormat("dd MMM HH:mm", Locale("id", "ID")).format(Date(time))
