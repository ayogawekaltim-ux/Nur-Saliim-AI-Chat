package com.nurandsaliim.aichat

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

data class ChatRequest(
    val model: String,
    val messages: List<ApiMessage>,
    val temperature: Double = 0.7
)

data class ApiMessage(
    val role: String,
    val content: Any
)

data class ChatResponse(
    val choices: List<Choice> = emptyList(),
    val error: ApiError? = null
)

data class Choice(val message: ApiMessage? = null)
data class ApiError(val message: String? = null)

data class ModelsResponse(val data: List<RemoteModel> = emptyList())
data class RemoteModel(
    val id: String,
    val name: String? = null,
    val context_length: Int? = null,
    val pricing: Pricing? = null,
    val architecture: Architecture? = null
)
data class Pricing(val prompt: String? = null, val completion: String? = null)
data class Architecture(val input_modalities: List<String>? = null)

interface OpenRouterService {
    @POST("chat/completions")
    suspend fun chat(
        @Header("Authorization") auth: String,
        @Header("HTTP-Referer") referer: String = "https://nurandsaliim.app",
        @Header("X-Title") title: String = "Nur & Saliim AI Chat",
        @Body request: ChatRequest
    ): ChatResponse

    @GET("models")
    suspend fun models(): ModelsResponse
}

object OpenRouter {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://openrouter.ai/api/v1/")
        .client(OkHttpClient.Builder().build())
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val service: OpenRouterService = retrofit.create(OpenRouterService::class.java)
}
